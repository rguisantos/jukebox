//! Controle do mpv via socket IPC JSON (`mpv --input-ipc-server=/run/jbox/mpv.sock --idle`).
use std::{io::Write, os::unix::net::UnixStream};

pub struct Mpv { sock: UnixStream }

impl Mpv {
    pub fn conectar(path: &str) -> std::io::Result<Self> { Ok(Self { sock: UnixStream::connect(path)? }) }
    fn cmd(&mut self, args: serde_json::Value) -> std::io::Result<()> {
        let mut s = serde_json::json!({ "command": args }).to_string();
        s.push('\n');
        self.sock.write_all(s.as_bytes())
    }
    pub fn tocar(&mut self, arquivo: &str) -> std::io::Result<()> { self.cmd(serde_json::json!(["loadfile", arquivo, "replace"])) }
    pub fn parar(&mut self) -> std::io::Result<()> { self.cmd(serde_json::json!(["stop"])) }
    pub fn volume(&mut self, v: u8) -> std::io::Result<()> { self.cmd(serde_json::json!(["set_property", "volume", v])) }
}
