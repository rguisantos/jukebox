use rusqlite::{params, Connection};

pub struct Store { conn: Connection }

impl Store {
    pub fn abrir(path: &str) -> rusqlite::Result<Self> {
        let conn = Connection::open(path)?;
        conn.execute_batch(include_str!("../../../schema.sql"))?;
        Ok(Self { conn })
    }
    pub fn saldo(&self) -> rusqlite::Result<u32> {
        self.conn.query_row("SELECT saldo FROM creditos WHERE id=1", [], |r| r.get(0))
    }
    /// Altera o saldo e registra o histórico na mesma transação (sobrevive a queda de energia).
    pub fn ajustar_saldo(&mut self, delta: i64) -> rusqlite::Result<()> {
        let tx = self.conn.transaction()?;
        tx.execute("UPDATE creditos SET saldo = MAX(0, saldo + ?1) WHERE id=1", params![delta])?;
        tx.execute("INSERT INTO registro_creditos(delta) VALUES (?1)", params![delta])?;
        tx.commit()
    }
    pub fn enfileirar(&self, midia_id: i64) -> rusqlite::Result<()> {
        self.conn.execute("INSERT INTO fila(midia_id) VALUES (?1)", params![midia_id]).map(|_| ())
    }
    pub fn proxima_da_fila(&mut self) -> rusqlite::Result<Option<i64>> {
        let tx = self.conn.transaction()?;
        let item: Option<(i64, i64)> = tx
            .query_row("SELECT id, midia_id FROM fila ORDER BY id LIMIT 1", [], |r| Ok((r.get(0)?, r.get(1)?)))
            .ok();
        if let Some((id, midia)) = item {
            tx.execute("DELETE FROM fila WHERE id=?1", params![id])?;
            tx.execute("INSERT INTO registro_execucoes(midia_id) VALUES (?1)", params![midia])?;
            tx.commit()?;
            Ok(Some(midia))
        } else { Ok(None) }
    }
}
