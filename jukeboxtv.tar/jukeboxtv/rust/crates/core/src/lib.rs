//! Regras de domínio, sem I/O: créditos e fila.

/// Relação configurável: `moedas` unidades de crédito dão `musicas` execuções.
#[derive(Debug, Clone, Copy)]
pub struct Relacao { pub moedas: u32, pub musicas: u32 }

/// Bônus por valor de cédula (centavos -> créditos extras).
#[derive(Debug, Clone, Default)]
pub struct Incentivos(pub Vec<(u32, u32)>);

#[derive(Debug, Default)]
pub struct Creditos { pub saldo: u32 }

impl Creditos {
    pub fn inserir(&mut self, centavos: u32, inc: &Incentivos) {
        let bonus = inc.0.iter().find(|(v, _)| *v == centavos).map_or(0, |(_, b)| *b);
        self.saldo += 1 + bonus;
    }
    /// Consome 1 crédito; `false` se não houver saldo.
    pub fn consumir(&mut self) -> bool {
        if self.saldo == 0 { return false; }
        self.saldo -= 1;
        true
    }
}

#[derive(Debug, Clone, PartialEq)]
pub struct ItemFila { pub midia_id: i64 }

#[derive(Debug, Default)]
pub struct Fila(pub Vec<ItemFila>);

impl Fila {
    pub fn enfileirar(&mut self, midia_id: i64) { self.0.push(ItemFila { midia_id }); }
    pub fn proxima(&mut self) -> Option<ItemFila> {
        if self.0.is_empty() { None } else { Some(self.0.remove(0)) }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn consome_e_bonus() {
        let mut c = Creditos::default();
        c.inserir(200, &Incentivos(vec![(200, 1)]));
        assert_eq!(c.saldo, 2);
        assert!(c.consumir() && c.consumir() && !c.consumir());
    }
    #[test]
    fn fila_fifo() {
        let mut f = Fila::default();
        f.enfileirar(1); f.enfileirar(2);
        assert_eq!(f.proxima().unwrap().midia_id, 1);
    }
}
