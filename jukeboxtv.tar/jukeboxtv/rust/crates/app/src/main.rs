use jbox_core::Incentivos;
use jbox_store::Store;

fn main() -> Result<(), Box<dyn std::error::Error>> {
    let mut store = Store::abrir("jbox.db")?;
    let _inc = Incentivos::default();
    println!("saldo atual: {}", store.saldo()?);
    // TODO: loop de eventos (evdev) -> Acao -> crédito/fila/player; ver docs/RELATORIO.md §4.
    store.ajustar_saldo(0)?;
    Ok(())
}
