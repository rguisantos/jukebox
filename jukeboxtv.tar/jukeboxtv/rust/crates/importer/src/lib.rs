//! Leitura de tags em Rust puro: arquivo ruim vira `Err`, nunca derruba o processo.
use lofty::{file::TaggedFileExt, probe::Probe, tag::Accessor};
use std::path::Path;

#[derive(Debug)]
pub struct TagInfo { pub titulo: Option<String>, pub artista: Option<String>, pub album: Option<String> }

pub fn ler_tags(p: &Path) -> Result<TagInfo, lofty::error::LoftyError> {
    let f = Probe::open(p)?.read()?;
    let t = f.primary_tag().or_else(|| f.first_tag());
    Ok(TagInfo {
        titulo: t.and_then(|t| t.title().map(|s| s.to_string())),
        artista: t.and_then(|t| t.artist().map(|s| s.to_string())),
        album: t.and_then(|t| t.album().map(|s| s.to_string())),
    })
}
