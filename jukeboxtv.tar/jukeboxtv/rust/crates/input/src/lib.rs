//! Mapa de teclas do painel (placa HID) -> ações. Leitura via evdev (/dev/input/eventX).
use evdev::Key;

#[derive(Debug, Clone, Copy, PartialEq)]
pub enum Acao { Cima, Baixo, Esquerda, Direita, Escolhe, Contextual, CancelaOuPula, Volume, Credito, Config }

pub fn mapear(k: Key) -> Option<Acao> {
    Some(match k {
        Key::KEY_Q => Acao::Cima,
        Key::KEY_W => Acao::Baixo,
        Key::KEY_E => Acao::Esquerda,
        Key::KEY_R => Acao::Direita,
        Key::KEY_I => Acao::Escolhe,
        Key::KEY_O => Acao::Contextual,
        Key::KEY_U => Acao::CancelaOuPula,
        Key::KEY_P => Acao::Volume,
        Key::KEY_Z => Acao::Credito,
        Key::KEY_X => Acao::Config,
        _ => return None,
    })
}
