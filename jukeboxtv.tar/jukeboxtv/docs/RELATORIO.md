# Jukebox TV 2.2 (jar v28) — Relatório técnico

## 1. Visão geral
Jukebox comercial para Linux (créditos, moedeiro, relatórios de execução). Java 6 (bytecode v50),
JRE 1.6.0_33 32 bits, Debian da época do glibc 2.13. Código ofuscado: 108 classes (`obfs.*`, nomes de 1 letra).
Só os pontos de entrada ficaram legíveis. O manifest não tem `Main-Class`; os scripts passam a classe.

Bibliotecas: Swing (UI), vlcj 2.1.0 (VLC), PostgreSQL JDBC 9.1, javax.usb (jsr80), JNA, log4j, jdom,
TagLib nativa (`libtag.so.1`) para tags de áudio.

## 2. Componentes
| Peça | Papel |
|---|---|
| `jjbox.controller.MainCaller` → `MainController` | Player + UI (120 campos, ~137 métodos, `KeyListener`). Núcleo do sistema. |
| `jjbox.loader.MusicAdminGUI` | Importador: varre Estilo/Artista/Disco/Música, valida capas e espaço em disco. |
| `jjbox.updater.MainUpdater` | Atualizador. |
| `scripts/*.sh` | `jukebox.sh` (`-Xms512m -Xmx2g`, `nice -10`), `importador.sh`, `atualizador.sh`, `zeroing.sh`, `unregister.sh`. |

Telas (CardLayout no `MainController`): INTERFACE geral, painel DISCOS, ESTILO, CONFIG, VIDEO, VIDEO_RANDOM.

## 3. Modelo de dados (inferido)
PostgreSQL local `jukeboxtvdb`. Tabelas: `estilo`, `artista`, `disco`, `midia`, `tipo_disco`, `tipo_midia`,
`gravadora`, `equalizer`, `brinde`, `filamidia`, `registro_musicas`, `registro_creditos`,
`registro_propagandas`, `sistema`.

- `sistema` (~60 colunas) concentra a configuração: códigos de tecla, relação de crédito, modo festa,
  modo aleatório, % do locatário, incentivos por cédula (R$2–R$50), sorteio de brinde, redução automática
  de volume por horário, dual monitor, senha de relatório.
- Créditos: saldo em `sistema`, histórico em `registro_creditos`, persistidos a cada alteração.
- Fila: `filamidia` (sobrevive a queda de energia).
- Relatórios: `registro_musicas` / `registro_propagandas` com flag `exportado`; XML de execuções para ABLF/APROVA.
- UI: grade 5×2 capas, paginação `limit/offset`, 10 páginas em cache; capa no banco (`disco.capa`).
- Porta 9533 (HTTP de push local): existência vista no bytecode; uso não confirmado.

## 4. Regras de negócio relevantes para o port
1. Crédito → músicas pela relação configurável; incentivos por valor de cédula somam bônus.
2. Fila persistida; reprodução retoma após reinício.
3. Modo festa / aleatório / vídeos aleatórios entre músicas; propaganda intercalada com registro próprio.
4. Redução automática de volume por faixa de horário.
5. Cada execução gera registro (música, data, créditos) marcado `exportado=false` até exportar.
6. Divisão de receita com locatário (% configurável) nos relatórios.

## 5. Estabilidade
Três `hs_err` (2015, 2016, 2021): SIGSEGV em `TagLib::FileRef::tag/create`. Uma tag/arquivo problemático
derruba a JVM inteira (falha nativa não é capturável). No port: ler tags com crate Rust pura (`lofty`),
em `Result`, e importar offline.

## 6. Pontos a NÃO portar
- Licenciamento (softlock / hardlock USB / contra-senha): o novo projeto não terá nenhum desses mecanismos.
  Este pacote não documenta como o sistema antigo valida licença e nenhum código de lock foi copiado.
- Chaves e senhas fixas: a atualização usava senha fixa em texto e a "criptografia" dos bundles usava chave
  guardada ao lado do jar. Esses valores foram removidos de `docs/config_reference.properties`.
  No port, assinar pacotes (minisign) e não rodar o player como root.

## 7. Aviso de propriedade
O código original é de terceiros (M4 & MGL Diversões Eletrônicas). Este material serve para entender
comportamento e requisitos; o port em Rust deve ser escrita nova, sem copiar código decompilado, e
só deve reutilizar o original se você tiver direito sobre ele.

## 8. Limites da análise
Sem decompilador disponível: li bytecode com um parser próprio (`docs/bytecode/`). Não reconstruí a máquina de
estados fina do `MainController` nem o protocolo USB do moedeiro (o port usa o pulso de moedeiro via teclado HID,
como no seu projeto atual).

## 9. Plano do port em Rust
Workspace em `rust/`: `core` (domínio: créditos, fila, regras), `store` (SQLite), `importer` (lofty),
`input` (evdev, mapa de teclas), `player` (mpv via IPC JSON), `app` (orquestra). Esqueleto **não compilado**
(sem cargo neste ambiente): rode `cargo check` e ajuste versões de dependências.
