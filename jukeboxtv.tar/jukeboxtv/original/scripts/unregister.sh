#!/bin/bash
rm /root/jukeboxtv/resources/release.bin

