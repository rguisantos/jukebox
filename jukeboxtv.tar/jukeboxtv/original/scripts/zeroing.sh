#!/bin/bash
rm -fr /home/jukeboxtv/database/c*
rm -fr /home/jukeboxtv/database/1*
rm -fr /home/jukeboxtv/database/2*
rm -fr /home/jukeboxtv/database/*
