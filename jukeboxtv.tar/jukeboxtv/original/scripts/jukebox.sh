#!/bin/bash
export JAVA_HOME=/usr/lib/jvm/jre1.6.0_33
export LD_LIBRARY_PATH=$JAVA_HOME/lib/i386
JAVA_BIN=$JAVA_HOME/bin/java
ROOT_FOLDER="/root/jukeboxtv"
LIBS_FOLDER="$ROOT_FOLDER/libs"
EXTERNALLIBS_FOLDER="$ROOT_FOLDER/resources"
MAIN_JAR="jukeboxtv.jar"
CLASSPATH=""
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/jdom.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/jna-3.4.0.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/jsr80-1.0.1.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/jsr80_linux.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/linux-i386.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/log4j-1.2.16.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/platform-3.4.0.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/postgresql-9.1-901.jdbc4.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/vlcj-2.1.0.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/core.jar"
CLASSPATH=$CLASSPATH":$LIBS_FOLDER/javase.jar"
CLASSPATH=$CLASSPATH":$ROOT_FOLDER/$MAIN_JAR"
MAINCLASS="jjbox.controller.MainCaller"
cd $ROOT_FOLDER

#echo "Aguardando checagem moedeiro/loteiro..."
#read -n1 -t1 -s TECLA
#if [ $TECLA ]; then
#	echo "  ------ PROBLEMAS NA CHECAGEM DA INTERFACE ------"
#	echo " "
#	echo " "
#	echo " Tecla travada : "$TECLA
#	sleep 1200
#	exit
#else
#	echo "Checagem OK! Prosseguindo..."
#fi

if [ "$#" -eq 0 ]
then
	nice -n -10 $JAVA_BIN -Djava.library.path=$EXTERNALLIBS_FOLDER -cp "$CLASSPATH" -Xms512m -Xmx2g "$MAINCLASS"
else
	if [ '/sobre' == $1 ]
	then
		$JAVA_BIN -cp "$CLASSPATH" -Xms64m -Xmx1g "$MAINCLASS" $1
		read -n 1 -s
	fi
fi

